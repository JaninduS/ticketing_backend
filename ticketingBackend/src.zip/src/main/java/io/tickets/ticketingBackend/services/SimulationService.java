package io.tickets.ticketingBackend.services;

import io.tickets.ticketingBackend.task.Customer;
import io.tickets.ticketingBackend.task.Vendor;
import org.springframework.stereotype.Service;

@Service
public class SimulationService {
    private final TicketPoolService ticketPoolService;

    public SimulationService(TicketPoolService ticketPoolService) {
        this.ticketPoolService = ticketPoolService;
    }

    public void startSimulation(int vendorCount, int customerCount, int ticketsPerRelease) {
        // Create vendor threads
        for (int i = 0; i < vendorCount; i++) {
            Thread vendorThread = new Thread(new Vendor("Vendor-" + i, ticketPoolService, ticketsPerRelease));
            vendorThread.start();
        }

        // Create customer threads
        for (int i = 0; i < customerCount; i++) {
            Thread customerThread = new Thread(new Customer("Customer-" + i, ticketPoolService));
            customerThread.start();
        }
    }
}
