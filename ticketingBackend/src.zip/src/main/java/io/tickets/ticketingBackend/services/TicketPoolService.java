package io.tickets.ticketingBackend.services;

import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import io.tickets.ticketingBackend.model.Ticket;
import io.tickets.ticketingBackend.repository.TicketRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketPoolService {
    private final BlockingQueue<Ticket> ticketQueue;
    private final TicketRepository ticketRepository;
    private int maxCapacity;

    public TicketPoolService(TicketRepository ticketRepository) {
        this.maxCapacity = 50;
        this.ticketQueue = new ArrayBlockingQueue<>(maxCapacity);
        this.ticketRepository = ticketRepository;
    }

    public List<Ticket> getAllTickets() {
        return ticketRepository.findAll();
    }

    public void addTickets(Ticket ticket) throws InterruptedException {
        ticketQueue.put(ticket);
        ticketRepository.save(ticket);
    }

    public Ticket removeTicket() throws InterruptedException {
        Ticket ticket = ticketQueue.take();
        ticketRepository.delete(ticket);
        return ticket;
    }

    public int getRemainingTickets() {
        return ticketQueue.size();
    }
}

