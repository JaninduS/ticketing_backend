package io.tickets.ticketingBackend.task;

import io.tickets.ticketingBackend.model.Person;
import io.tickets.ticketingBackend.model.Ticket;
import io.tickets.ticketingBackend.services.TicketPoolService;

import java.util.UUID;

public class Vendor extends Person implements Runnable {
    private final TicketPoolService ticketPoolService;
    private final int ticketsPerRelease;

    public Vendor(String name, TicketPoolService ticketPoolService, int ticketsPerRelease) {
        super(name);
        this.ticketPoolService = ticketPoolService;
        this.ticketsPerRelease = ticketsPerRelease;
    }

    @Override
    public void run() {
        try {
            while (true) {
                for (int i = 0; i < ticketsPerRelease; i++) {
                    Ticket ticket = new Ticket("Ticket-" + UUID.randomUUID());
                    ticketPoolService.addTickets(ticket);
                    System.out.println(Thread.currentThread().getName() + " added " + ticket);
                }
                Thread.sleep(2000); // Simulate release rate
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

