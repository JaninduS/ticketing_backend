package io.tickets.ticketingBackend.controller;

import io.tickets.ticketingBackend.model.Ticket;
import io.tickets.ticketingBackend.services.SimulationService;
import io.tickets.ticketingBackend.services.TicketPoolService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/tickets")
public class TicketingController {

    private final SimulationService simulationService;
    private final TicketPoolService ticketPoolService;

    public TicketingController(SimulationService simulationService, TicketPoolService ticketPoolService) {
        this.simulationService = simulationService;
        this.ticketPoolService = ticketPoolService;
    }

    // Endpoint to start the simulation
    @PostMapping("/start")
    public String startSimulation(
            @RequestParam int vendorCount,
            @RequestParam int customerCount,
            @RequestParam int ticketsPerRelease
    ) {
        simulationService.startSimulation(vendorCount, customerCount, ticketsPerRelease);
        return "Simulation started with " + vendorCount + " vendors and " + customerCount + " customers.";
    }

    // Endpoint to get all tickets currently in the pool
    @GetMapping("/get-all")
    public List<Ticket> getAllTickets() {
        return ticketPoolService.getAllTickets();
    }

    // Endpoint to get the number of remaining tickets in the pool
    @GetMapping("/remaining")
    public int getRemainingTickets() {
        return ticketPoolService.getRemainingTickets();
    }
}

