package io.tickets.ticketingBackend.task;

import io.tickets.ticketingBackend.model.Person;
import io.tickets.ticketingBackend.model.Ticket;
import io.tickets.ticketingBackend.services.TicketPoolService;

public class Customer extends Person implements Runnable {
    private final TicketPoolService ticketPoolService;

    public Customer(String name, TicketPoolService ticketPoolService) {
        super(name);
        this.ticketPoolService = ticketPoolService;
    }

    @Override
    public void run() {
        try {
            while (true) {
                Ticket ticket = ticketPoolService.removeTicket();
                System.out.println(Thread.currentThread().getName() + " purchased " + ticket);
                Thread.sleep(1000); // Simulate purchase rate
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

