package io.tickets.ticketingBackend.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Ticket {
    @Id
    @GeneratedValue
    private Long id;
    private String code;

    public Ticket() {

    }

    public Ticket(Long id, String code) {
        this.id = id;
        this.code = code;
    }

    public Ticket(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    @Override
    public String toString() {
        return "Ticket{id=" + id + ", code='" + code + "'}";
    }
}

