package io.tickets.ticketingBackend.cli;

import io.tickets.ticketingBackend.model.Ticket;
import io.tickets.ticketingBackend.services.TicketPoolService;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TicketingCLI {

    public TicketingCLI() {

    }

    public void start() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Ticketing System CLI");

        // Get system parameters
        System.out.print("Enter total tickets: ");
        int totalTickets = Integer.parseInt(scanner.nextLine());

        System.out.print("Enter ticket release rate (tickets/sec): ");
        int ticketReleaseRate = Integer.parseInt(scanner.nextLine());

        System.out.print("Enter customer retrieval rate (tickets/sec): ");
        int customerRetrievalRate = Integer.parseInt(scanner.nextLine());

        System.out.print("Enter max ticket capacity: ");
        int maxCapacity = Integer.parseInt(scanner.nextLine());

        // Start simulation
        System.out.println("Starting simulation...");
        startSimulation(totalTickets, ticketReleaseRate, customerRetrievalRate);

        System.out.println("Simulation complete!");
    }

    private void startSimulation(int totalTickets, int ticketReleaseRate, int customerRetrievalRate) {
        List<Thread> vendorThreads = new ArrayList<>();
        List<Thread> customerThreads = new ArrayList<>();
        int totalVendors = 2; // Number of vendor threads
        int totalCustomers = 2; // Number of customer threads

        // Shared counters for simulation progress
        int[] ticketsAdded = {0}; // Shared counter for tickets added
        int[] ticketsRetrieved = {0}; // Shared counter for tickets retrieved

        // Create and start vendor threads
        for (int i = 0; i < totalVendors; i++) {
            Thread vendorThread = new Thread(() -> {
                try {
                    while (ticketsAdded[0] < totalTickets) {
                        synchronized (ticketsAdded) {
                            if (ticketsAdded[0] < totalTickets) {
                                String ticketCode = "Ticket-" + ticketsAdded[0];
                                Ticket ticket = new Ticket(ticketCode);
                                ticketPoolService.addTicket(ticket);
                                ticketsAdded[0]++;
                                System.out.println("Vendor added: " + ticketCode + " (Total added: " + ticketsAdded[0] + ")");
                            }
                        }
                        Thread.sleep(1000 / ticketReleaseRate); // Release tickets at the specified rate
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }, "Vendor-" + i);
            vendorThreads.add(vendorThread);
            vendorThread.start();
        }

        // Create and start customer threads
        for (int i = 0; i < totalCustomers; i++) {
            Thread customerThread = new Thread(() -> {
                try {
                    while (ticketsRetrieved[0] < totalTickets) {
                        synchronized (ticketsRetrieved) {
                            if (ticketsRetrieved[0] < totalTickets) {
                                Ticket ticket = ticketPoolService.removeTicket();
                                ticketsRetrieved[0]++;
                                System.out.println("Customer retrieved: " + ticket + " (Total retrieved: " + ticketsRetrieved[0] + ")");
                            }
                        }
                        Thread.sleep(1000 / customerRetrievalRate); // Retrieve tickets at the specified rate
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }, "Customer-" + i);
            customerThreads.add(customerThread);
            customerThread.start();
        }

        // Wait for all threads to complete
        for (Thread thread : vendorThreads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        for (Thread thread : customerThreads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
