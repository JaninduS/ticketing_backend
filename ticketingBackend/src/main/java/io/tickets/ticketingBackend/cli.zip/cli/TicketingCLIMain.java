package io.tickets.ticketingBackend.cli;

import io.tickets.ticketingBackend.cli.TicketingCLI;
import io.tickets.ticketingBackend.services.TicketPoolService;
import io.tickets.ticketingBackend.repository.TicketRepository;

public class TicketingCLIMain {
    public static void main(String[] args) {
        // Create a mock repository (replace with Spring context for real application)

        // Create the TicketPoolService

        // Start the CLI
        TicketingCLI ticketingCLI = new TicketingCLI(ticketPoolService);
        ticketingCLI.start();
    }
}

